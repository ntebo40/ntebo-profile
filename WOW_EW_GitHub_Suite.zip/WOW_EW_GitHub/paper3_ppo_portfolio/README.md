# Paper 3 — PPO Portfolio Agent

**Title:** Deep Reinforcement Learning for Cryptocurrency Portfolio Management:
A Free-Energy PPO Framework with Geodesic Transaction Costs and
Thermodynamic Efficiency Bounds

**Author:** N.D. Moroke  
**Journal:** Risks (MDPI) — Submitted March 2026  
**DOI:** 10.3390/risks00000000 *(update after acceptance)*

## Key Results

| Asset | Sharpe (Geom. PPO) | Friction Point c* | Carnot η |
|-------|-------------------|-------------------|---------|
| BTC | 0.61 [0.53, 0.69] | 0.6% [0.5, 0.8] | 0.041 |
| ETH | 0.74 [0.66, 0.82] | 1.8% [1.6, 2.1] | 0.127 |
| XRP | 0.69 [0.61, 0.77] | 1.2% [1.0, 1.4] | 0.089 |
| LTC | 0.71 [0.63, 0.79] | 1.4% [1.2, 1.6] | 0.108 |
| BCH | 0.66 [0.58, 0.74] | 1.0% [0.8, 1.2] | 0.075 |

**Portfolio Carnot Bound:** η ≤ 1 − H_turb/H_calm  
**Spearman ρ(η, τ½):** 0.94 (p = 0.017)  
**Max DD reduction (circuit breaker):** 28–38%

## Files

| File | Description |
|------|-------------|
| `ppo_agent.py` | PPO with free-energy reward, geodesic costs, circuit breaker |
| `carnot_bound.py` | η computation and bound validation |
| `friction_sensitivity.py` | c* sweep and Spearman analysis |
| `generate_figures.py` | Reproduces all 5 manuscript figures |
| `requirements.txt` | Python dependencies |

## Quick Start

```bash
pip install -r requirements.txt

# Download data
python -c "import yfinance as yf; yf.download(['BTC-USD','ETH-USD',
'XRP-USD','LTC-USD','BCH-USD'], start='2017-01-01',
end='2026-03-08').to_csv('../data/crypto_market_data.csv')"

# Run friction sensitivity analysis
python friction_sensitivity.py --asset ETH --fee-levels 0.001 0.002 0.005 0.01 0.02 0.05 0.1

# Generate all figures
python generate_figures.py
```

## Dependencies
- Python 3.11+
- stable-baselines3 2.3
- PyTorch 2.1
- scipy, numpy, matplotlib, yfinance
