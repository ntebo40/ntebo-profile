# Paper 2 — GRU Turbulence Filter

**Title:** GRU Turbulence Filter for Cryptocurrency Return Dynamics:
A Navier-Stokes Viscosity Analogy

**Authors:** L.D. Metsileng & N.D. Moroke  
**Journal:** TBD — In preparation  

## Concept

Establishes a functional identity:

```
GRU update:          h_t = (1 - z_t) ⊙ h_{t-1} + z_t ⊙ h̃_t
Navier-Stokes:       u^{n+1} = u^n + Δt(-u^n·∇u^n + ν∇²u^n)

Correspondence:
  z_t  ↔  ν Δt ∇²   (update gate = viscosity coefficient)
  h_{t-1} ↔  u^n    (hidden state = velocity field)
```

Regime-conditioned loss function (uses Paper 1 outputs):
```
L = Σ_t [ξ̂_t(2) · QLIKE_t + (1 - ξ̂_t(2)) · MSE_t]
```

## Status: In preparation
Code and results will be added upon manuscript completion.
