# Dataset: WOW-E-W Quadrilogy Cryptocurrency Data

## Zenodo DOI
[![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.XXXXXXX.svg)](https://doi.org/10.5281/zenodo.XXXXXXX)

> Replace XXXXXXX with your real Zenodo DOI after deposit.

## Contents

| File | Description | Size |
|------|-------------|------|
| `crypto_market_data.csv` | Daily OHLCV, all 5 assets, 2017–2026 | ~2.1 MB |
| `regime_probabilities.csv` | Hamilton filter outputs ξ̂_t(2) from Paper 1 | ~480 KB |
| `fisher_metrics.csv` | G_t, κ_t, β₀,β₁, W_t from Paper 2.5 | ~1.8 MB |

## Variables

### crypto_market_data.csv
| Column | Description |
|--------|-------------|
| Date | Trading date (YYYY-MM-DD) |
| BTC_Open, BTC_High, BTC_Low, BTC_Close | BTC-USD OHLC |
| BTC_Volume | BTC daily volume (USD) |
| ETH_*, XRP_*, LTC_*, BCH_* | Same structure for other assets |

### regime_probabilities.csv
| Column | Description |
|--------|-------------|
| Date | Trading date |
| BTC_xi2, ETH_xi2, XRP_xi2, LTC_xi2, BCH_xi2 | P(turbulent regime) from Hamilton filter |
| BTC_sigma2_calm, BTC_sigma2_turb | Regime-conditional variances |

### fisher_metrics.csv
| Column | Description |
|--------|-------------|
| Date | Trading date |
| BTC_G, ETH_G, ... | Fisher metric (geometric mean eigenvalue, scaled) |
| BTC_kappa, ETH_kappa, ... | Ricci scalar |
| BTC_beta0, ETH_beta0, ... | Betti-0 (connected components) |
| BTC_beta1, ETH_beta1, ... | Betti-1 (loops) |
| BTC_W, ETH_W, ... | Wasserstein-2 dissipation |

## Data Collection

```python
import yfinance as yf
import pandas as pd

tickers = ['BTC-USD', 'ETH-USD', 'XRP-USD', 'LTC-USD', 'BCH-USD']
raw = yf.download(tickers, start='2017-01-01', end='2026-03-08',
                  auto_adjust=True)
raw.to_csv('crypto_market_data.csv')
```

## Sample Period

| Asset | Start | End | Obs. |
|-------|-------|-----|------|
| BTC-USD | 2017-01-01 | 2026-03-08 | 3,354 |
| ETH-USD | 2017-01-01 | 2026-03-08 | 3,042 |
| XRP-USD | 2017-01-01 | 2026-03-08 | 3,042 |
| LTC-USD | 2017-01-01 | 2026-03-08 | 3,354 |
| BCH-USD | 2017-08-02 | 2026-03-08 | 3,042 |

## License
CC BY 4.0 — cite the relevant paper(s) when using this data.

## How to Deposit on Zenodo
1. Go to https://zenodo.org
2. Click Upload → New Upload
3. Upload all 3 CSV files
4. Fill metadata (title, authors, keywords below)
5. Set Community: "Open Research Data"
6. License: CC BY 4.0
7. Click Publish → copy the DOI
8. Update all XXXXXXX placeholders in this repo with real DOI

### Zenodo Metadata Template
**Title:** WOW-E-W Quadrilogy: Cryptocurrency Market Data and
Regime Indicators (2017–2026)  
**Authors:** Metsileng, L.D.; Moroke, N.D.  
**Keywords:** cryptocurrency, Bitcoin, Ethereum, GARCH, regime switching,
Markov-switching, thermodynamics, portfolio management  
**Description:** Daily OHLCV data for five cryptocurrency assets (BTC, ETH,
XRP, LTC, BCH) over January 2017 to March 2026, with derived regime
probabilities and Riemannian geometry indicators from the WOW-E-W quadrilogy.
