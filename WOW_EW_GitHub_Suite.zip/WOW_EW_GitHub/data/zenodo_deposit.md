# Zenodo Deposit Checklist

## Step-by-step

1. Go to https://zenodo.org and log in
2. Click the "+" → New Upload
3. Upload files:
   - crypto_market_data.csv
   - regime_probabilities.csv  (from Paper 1 pipeline)
   - fisher_metrics.csv        (from Paper 2.5 pipeline)
4. Fill in metadata (copy from below)
5. Set Access: OPEN
6. License: Creative Commons Attribution 4.0 (CC-BY)
7. Click PUBLISH
8. Copy DOI: 10.5281/zenodo.XXXXXXX
9. Update README.md and CITATION.cff with real DOI
10. Update Data Availability section in all papers

---

## Zenodo Metadata (copy-paste ready)

**Resource type:** Dataset  

**Title:**  
WOW-E-W Quadrilogy: Cryptocurrency Market Data and Regime Indicators
(BTC, ETH, XRP, LTC, BCH — 2017 to 2026)

**Authors:**  
1. Metsileng, Lethiwe Doris — North-West University (add ORCID if available)
2. Moroke, Ntebogang Dinah — North-West University (ORCID: 0000-0001-8545-1860)

**Description:**  
Daily OHLCV price and volume data for five major cryptocurrencies
(Bitcoin, Ethereum, Ripple, Litecoin, Bitcoin Cash) sourced from
Yahoo Finance over January 2017 to March 2026 (15,834 asset-day
observations). Includes derived indicators: Hamilton filter regime
probabilities from the MS-GARCH-MaxEnt model (Paper 1), Fisher
metric, Ricci scalar, Betti numbers, and Wasserstein dissipation
from the Riemannian geometry pipeline (Paper 2.5). Generated in
support of the WOW-E-W Quadrilogy research programme on
thermodynamic portfolio management.

**Keywords:**  
cryptocurrency, Bitcoin, Ethereum, Ripple, Litecoin, Bitcoin Cash,
Markov-switching GARCH, maximum entropy, regime detection,
Hamilton filter, Fisher information, Riemannian geometry,
topological data analysis, Wasserstein distance, portfolio
management, deep reinforcement learning, thermodynamics,
financial time series

**Related publications:**  
- Paper 3: Risks (MDPI), submitted March 2026
- Paper 2.5: IEEE Access, under review
- Paper 1: Expert Systems with Applications, under review

**Version:** 1.0.0  
**Language:** English  
**Community:** Open Research Data
