# Paper 1 — MS-GARCH-MaxEnt Expert System

**Title:** The Statistical Mechanics of Cryptocurrency Volatility Regimes:
A Maximum-Entropy Markov-Switching GARCH Framework

**Authors:** L.D. Metsileng & N.D. Moroke  
**Journal:** Expert Systems with Applications (Elsevier) — Under review  
**arXiv:** 2603.XXXXX *(update after deposit)*

## Key Findings

| Asset | τ½(calm) | τ½(turb) | π(turb) | Phase |
|-------|----------|----------|---------|-------|
| BTC | 0.30 days† | 2.71 days | 0.800 | Boiling |
| ETH | 1.80 days  | 31.74 days | 0.937 | Kinetic Trap |
| XRP | 0.71 days† | 10.92 days | 0.910 | Collapse |
| LTC | 0.89 days† | 18.09 days | 0.935 | Collapse |
| BCH | 1.02 days  | 14.88 days | 0.915 | Near-Critical |

† Boiling-point criterion: τ½(calm) < 1 day

**Calm-Phase Fragility Law:** turbulence accounts for 80–94% of all trading days  
**BTC Permanent Criticality:** τ½(calm) = 0.30 days — no structured model can
consistently beat persistence

## Files

| File | Description |
|------|-------------|
| `ms_garch_maxent_estimation.py` | EM + Hamilton filter + MaxEnt calibration |
| `thermodynamic_diagnostics.py` | Half-lives, order parameter, boiling-point rules |
| `requirements.txt` | Python dependencies |
