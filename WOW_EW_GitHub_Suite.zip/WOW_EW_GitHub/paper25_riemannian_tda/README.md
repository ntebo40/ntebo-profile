# Paper 2.5 — Riemannian Geometry and TDA

**Title:** Riemannian Geometry and Topological Data Analysis for
Cryptocurrency Liquidity Risk: Fisher Metrics, Persistent Homology,
and a Statistical Operations Research Framework for Geodesic
Execution Slippage

**Authors:** L.D. Metsileng & N.D. Moroke  
**Journal:** IEEE Access — Under review  
**arXiv:** 2603.XXXXX *(update after deposit)*

## Key Outputs

- Fisher metric G_t (60-day rolling outer-product estimator)
- Ricci scalar κ_t (auto-diff of Levi-Civita connection)
- Betti numbers β₀,t and β₁,t (Vietoris-Rips on Level-2 order book)
- Wasserstein-2 dissipation W_t (Sinkhorn algorithm)
- Geodesic slippage S* (arc length on Fisher manifold)

## Files

| File | Description |
|------|-------------|
| `fisher_manifold.py` | G_t estimation from score gradients |
| `persistent_homology.py` | TDA pipeline for order book topology |
| `geodesic_slippage.py` | S* computation via geodesic integration |
| `requirements.txt` | Python dependencies |
